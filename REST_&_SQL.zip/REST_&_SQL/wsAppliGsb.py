#!/usr/bin/python
# -*- coding: utf-8 -*-

from flask import *
import json
import mysql.connector

# Créer l'objet Application Flask (Serveur)
app = Flask( __name__ )

# Obtenir une connexion au SGBDR
connexionBD = mysql.connector.connect(
			host = 'localhost' ,
			user = 'root' ,
			password = 'azerty' ,
			database = 'AppGSB'
		)

# Page d'accueil
@app.route( '/' )
def accueil() :
	# Retourne un simple message (texte brut)
	return "Gsb Services web"

'''##########################################'''
# Liste des Visiteurs

@app.route( '/connexion/<matricule>/<mdp>' , methods=['GET'] )
def seConnecter(matricule, mdp) :
	pass
	# Obtenir un curseur
	curseur = connexionBD.cursor()
	# Exécuter la requête
	curseur.execute( 'select * from VISITEUR WHERE VIS_MATRICULE = %s AND VIS_MDP = %s' , (matricule, mdp))
	# Lire tous les tuples qui résultent de l'exécution de la requête
	tuples = curseur.fetchall()
	# Fermer le curseur
	curseur.close()

	# Parcourir tous les tuples qui résultent de l'exécution de la requête
	for unTuple in tuples :
		# Convertir le tuple en dictionnaire (tableau associatif)
		unVisiteur = { 'matricule': unTuple[0] , 'nom': unTuple[1] , 'prenom': unTuple[2], 'adresse': unTuple[3],
		'cp': unTuple[4], 'ville': unTuple[5],'dateEmbauche': str(unTuple[6]), 'sec_code': unTuple[7], 'labCode': unTuple[8],'mdp': unTuple[9],}
		# Ajouter le dictionnaire dans la liste des livreurs

	# Convertir la liste des livreurs en chaîne au format JSON
	response = json.dumps( unVisiteur )
	print "Visiteur : " + response
	# Renvoyer la réponse au client HTTP
	return Response( response , status=200 , mimetype='application/json' )

'''##########################################'''
# liste rapports visite

@app.route( '/listeRv/<mois>/<annee>' , methods=['GET'] )
def getRapportsVisite(mois, annee) :
	pass
	# Obtenir un curseur
	curseur = connexionBD.cursor()
	# Exécuter la requête
	curseur.execute( 'select  rv.*, v.VIS_NOM, v.VIS_PRENOM, p.PRA_NOM, p.PRA_PRENOM, m.LIBELLE_MOTIF from RAPPORT_VISITE as rv INNER JOIN MOTIF m'
	+' ON rv.RAP_MOTIF = m.NUM_MOTIF INNER JOIN VISITEUR v ON rv.VIS_MATRICULE = v.VIS_MATRICULE INNER JOIN PRATICIEN p ON rv.PRA_NUM = p.PRA_NUM '
	+' WHERE MONTH(rv.RAP_DATE) = %s AND YEAR(rv.RAP_DATE) = %s' , (mois, annee))
	# Lire tous les tuples qui résultent de l'exécution de la requête
	tuples = curseur.fetchall()
	# Fermer le curseur
	curseur.close()
	#Liste de rapport de visite vide
	RapportsVisites = []
	# valeur null si pas de tuple
	i = 0
	# Parcourir tous les tuples qui résultent de l'exécution de la requête
	for tupleExiste in tuples :
		i += 1

	if i == 0 :
		unRv = {}
		RapportsVisites.append( unRv )
	else :
		for unTuple in tuples :
		# Convertir le tuple en dictionnaire (tableau associatif)
			unRv = { 'matricule': unTuple[0] , 'numRv': unTuple[1] , 'numPra': unTuple[2], 'bilanRv': unTuple[3],
			'vuRv': unTuple[4], 'dateRv': str(unTuple[5]), 'motifRv': unTuple[6], 'coefConfRv': unTuple[7],
			'visNom' : unTuple[8],'visPrenom' : unTuple[9],
			'praNom': unTuple[10],'praPrenom': unTuple[11], 'libelleMotif': unTuple[12],}
			# Ajouter le dictionnaire dans la liste des livreurs
			RapportsVisites.append( unRv )

	# Convertir la liste des livreurs en chaîne au format JSON
	response = json.dumps( RapportsVisites )
	print "Rapports de Visite : " + response
	# Renvoyer la réponse au client HTTP
	return Response( response , status=200 , mimetype='application/json' )

'''##########################################'''
# Liste des échantillons par rapport à un rv

@app.route( '/echantillons/<num>/<matricule>' , methods=['GET'] )
def getEchantillons( num, matricule ) :
	# Obtenir un curseur
	curseur = connexionBD.cursor()

	# Exécuter la requête
	curseur.execute( 'select m.MED_DEPOTLEGAL, m.MED_NOMCOMMERCIAL, f.FAM_LIBELLE, m.MED_COMPOSITION, m.MED_EFFETS, m.MED_CONTREINDIC, m.MED_PRIXECHANTILLON, o.QUANTITE '
	+'FROM MEDICAMENT m '
	+'INNER JOIN FAMILLE f '
	+'ON m.FAM_CODE = f.FAM_CODE '
	+'INNER JOIN OFFRIR o '
	+'ON m.MED_DEPOTLEGAL = o.MED_DEPOTLEGAL '
	+' where o.RAP_NUM = %s AND o.VIS_MATRICULE = %s' , (num, matricule)  )
	# Lire tous les tuples qui résultent de l'exécution de la requête
	tuples = curseur.fetchall()
	# Fermer le curseur
	curseur.close()
	# Créer une liste vide d'échantillons
	echantillons = []
	#Si il n'y a pas de tuple echantillons prend la valeur null
	i = 0
	for tupleExiste in tuples :

		i += 1

	if i == 0 :

		unEchantillon = {}
		echantillons.append( unEchantillon )

	else :
		# Parcourir tous les tuples qui résultent de l'exécution de la requête
		for unTuple in tuples :
			# Convertir le tuple en dictionnaire (tableau associatif)
			unEchantillon = { 'depotLegal': unTuple[0] , 'nomCommercial': unTuple[1] ,
			'famLibelle': unTuple[2] , 'composition' : unTuple[3] ,
			'effets': unTuple[4] , 'contreIndications' : unTuple[5] ,
			'prixEchantillon': unTuple[6] , 'quantite': unTuple[7] }


			# Ajouter le dictionnaire dans la liste des echantillons
			echantillons.append( unEchantillon )

	# Convertir la liste des echantillons en chaîne au format JSON
	reponse = json.dumps( echantillons )
	print "echantillons : " + reponse
	# Renvoyer la réponse au client HTTP
	return Response( reponse , status=200 , mimetype='application/json' )

'''##########################################'''
# Liste des praticiens

@app.route( '/praticiens' , methods=['GET'] )
def getPraticiens() :
	# Obtenir un curseur
	curseur = connexionBD.cursor()
	# Exécuter la requête
	curseur.execute( 'select pra.PRA_NUM, pra.PRA_NOM, pra.PRA_PRENOM, pra.PRA_COEFNOTORIETE, tp.TYP_CODE, tp_TYP_LIBELLE'
	+ 'FROM PRATICIEN pra '
	+ 'INNER JOIN TYPE_PRATICIEN tp '
	+ 'ON pra.TYP_CODE = tp.TYP_CODE ' )
	# Lire tous les tuples qui résultent de l'exécution de la requête
	tuples = curseur.fetchall()
	# Fermer le curseur
	curseur.close()
	# Créer une liste vide de praticiens
	praticiens = []
	#Si il n'y a pas de tuple praticiens prend la valeur null
	i = 0
	for tupleExiste in tuples :

		i += 1

	if i == 0 :

		unPraticien = {}
		praticiens.append( unPraticien )

	else :
		# Parcourir tous les tuples qui résultent de l'exécution de la requête
		for unTuple in tuples :
			# Convertir le tuple en dictionnaire (tableau associatif)
			unPraticien = { 'num': unTuple[0] , 'nom': unTuple[1] ,
			'prenom': unTuple[2] , 'coefficientNotoriete' : unTuple[3] , 'typeCode' : unTuple[4] , 'typeLibelle' : unTuple[5] }


			# Ajouter le dictionnaire dans la liste des praticiens
			praticiens.append( unPraticien )

	# Convertir la liste des praticiens en chaîne au format JSON
	reponse = json.dumps( praticiens )
	print "praticiens : " + reponse
	# Renvoyer la réponse au client HTTP
	return Response( reponse , status=200 , mimetype='application/json' )

"""
# Lire un livreur
@app.route( '/livreurs/<idLivreur>' , methods=['GET'] )
def getLivreur( idLivreur ) :
	pass
	# Votre code ici

	# Obtenir un curseur
	curseur = connexionBD.cursor()
	# Exécuter la requête
	curseur.execute( 'select id,nom,prenom from Livreur where id = %s ', (idLivreur,) )
	# Lire tous les tuples qui résultent de l'exécution de la requête
	tuples = curseur.fetchall()
	# Fermer le curseur
	curseur.close()
	#Si il n'existe pas alors il est null sinon retourne la valeur
	i = 0
	for tupleTrouver in tuples :
		i += 1
	if i == 0 :
		unLivreur = {}
	else :
		for unTuple in tuples :
			# Convertir le tuple en dictionnaire (tableau associatif)
			unLivreur = { 'id': unTuple[0] , 'nom': unTuple[1] , 'prenom': unTuple[2] }

	# Convertir la liste des livreurs en chaîne au format JSON
	reponse = json.dumps( unLivreur )
	print "Livreur : " + reponse
	# Renvoyer la réponse au client HTTP
	return Response( reponse , status=200 , mimetype='application/json' )

# Créer un livreur
@app.route( '/livreurs' , methods=['POST'] )
def addLivreur() :
	# Lire et mémoriser le corps de la requête (livreur sous la forme d'une chaîne JSON)
	unLivreurJSON = request.data
	# Convertir la chaîne JSON en dictionnaire
	unLivreur = json.loads( unLivreurJSON )
	#print unLivreur

	# Obtenir un curseur
	curseur = connexionBD.cursor()
	# Exécuter la requête
	curseur.execute( 'insert into Livreur(nom,prenom) values(%s,%s)' , ( unLivreur['nom'] , unLivreur['prenom'] ) )
	# Obtenir le dernier identifiant attribué
	idNouveauLivreur = curseur.lastrowid
	# Obtenir le nombre de tuples insérés (normallement, un seul)
	nbTuplesTraites = curseur.rowcount
	# S'assurer que la BD est mise à jour
	connexionBD.commit()
	# Fermer le curseur
	curseur.close()

	# Créer un objet réponse
	reponse = make_response( '' )
	# Si l'insertion du livreur s'est déroulée avec succès
	if nbTuplesTraites == 1 :
		reponse.mimetype = 'text/plain'
		reponse.status_code = 201
		reponse.location = '/livreurs/' + str( idNouveauLivreur )

	# Dans le cas contraire
	else :
		pass
		# Votre code
		reponse.mimetype = 'text/plain'
		reponse.status_code = 409
		reponse.location = '/livreurs/' + str( -1 )




	#print "Livreurs : " + reponse
	# Renvoyer la réponse au client HTTP
	#return Response( reponse , status=200 , mimetype='application/json' )

	return reponse


@app.route( '/livreurs/<idLivreur>' , methods=['DELETE'] )
def deleteLivreur(idLivreur):
	pass
	# Votre code ici

	# Exécuter la requête
	curseur = connexionBD.cursor()
	# Exécuter la requête
	curseur.execute( 'DELETE from Livreur where id = %s ', (idLivreur,) )
	# Lire tous les tuples qui résultent de l'exécution de la requête
	tuples = curseur.rowcount
	# S'assurer que la BD est mise à jour
	connexionBD.commit()
	# Fermer le curseur
	curseur.close()
	#Si il n'existe pas alors il est null sinon retourne la valeur
	if tuples == 0 :
		reponse = 'False'
		#reponse.mimetype = 'text/plain'
		#reponse.status_code = 201
		#reponse.location = '/livreurs/' + str( idNouveauLivreur )
	else :
		reponse = 'True'
		#reponse.mimetype = 'text/plain'
		#reponse.status_code = 409
		#reponse.location = '/livreurs/' + str( -1 )

	# Convertir la liste des livreurs en chaîne au format JSON
	#reponse = json.dumps( unLivreur )
	print "Supprimer : " + reponse
	# Renvoyer la réponse au client HTTP
	return reponse

@app.route( '/livreurs' , methods=['PUT'] )
def modifierLivreur():
	pass
	# Votre code ici
	# Lire et mémoriser le corps de la requête (livreur sous la forme d'une chaîne JSON)
	unLivreurJSON = request.data
	# Convertir la chaîne JSON en dictionnaire
	unLivreur = json.loads( unLivreurJSON )
	#print unLivreur

	# Obtenir un curseur
	curseur = connexionBD.cursor()
	# Exécuter la requête
	curseur.execute( 'UPDATE Livreur SET nom = %s , prenom = %s WHERE id = %s ', (unLivreur['nom'], unLivreur['prenom'], 	unLivreur['id']) )
	# Lire tous les tuples qui résultent de l'exécution de la requête
	tuples = curseur.rowcount
	# S'assurer que la BD est mise à jour
	connexionBD.commit()
	# Fermer le curseur
	curseur.close()
	#Si il n'existe pas alors il est null sinon retourne la valeur
	if tuples == 0 :
		reponse = 'False'

	else :
		reponse = 'True'

	# Convertir la liste des livreurs en chaîne au format JSON
	#reponse = json.dumps( unLivreur )
	print "Modifier: " + reponse
	# Renvoyer la réponse au client HTTP
	return Response( reponse , status=200 , mimetype='application/json' )
"""

# Programme principal
if __name__ == "__main__" :
	# Démarrer le serveur
	app.run( debug = True , host = '0.0.0.0' , port = 5000 )
