package fr.gsb.rv.gsb_rv_visiteur;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import fr.gsb.rv.entites.DateFr;

public class RechercherRvActivity extends AppCompatActivity {

    private static final String[] lesMois = {"1","2","3","4","5","6","7","8","9","10","11","12"};
    Spinner spMois;
    int annee = new DateFr().getAnnee();

    //private static ArrayList<int> Annee ;
    Spinner spAnnee;

    TextView testDonnee;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rechercher_rv);

        spMois = (Spinner) findViewById(R.id.spMois);
        spAnnee = (Spinner) findViewById(R.id.spAnnee);
        //testDonnee = (TextView) findViewById(R.id.testDonnee);



        //Mois spinner
        ArrayAdapter<String> aaMois = new ArrayAdapter<String>(
                this,
                android.R.layout.simple_spinner_item,
                lesMois
        );
        aaMois.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );
        spMois.setAdapter( aaMois);



        // création de la liste des années
        List<String> lesAnnees = new ArrayList<String>();
        for(int i = annee; i >= 2000 ; i-- )
        {
            lesAnnees.add("" + i);
        }
        //Années spinner
        ArrayAdapter<String> aaAnnee = new ArrayAdapter<String>(
                this,
                android.R.layout.simple_spinner_item,
                lesAnnees
        );
        aaAnnee.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );
        spAnnee.setAdapter( aaAnnee );

        //testDonnee.setText("Année: " + this.spAnnee.getSelectedItem().toString() + " Mois: " + this.spMois.getSelectedItem().toString());



    }

    public void AfficherListeRapport(View vue){
        //testDonnee.setText(spMois.getSelectedItem().toString() + " " + spAnnee.getSelectedItem().toString() );
        int mois = Integer.parseInt((String) spMois.getSelectedItem());
        int annee = Integer.parseInt((String) spAnnee.getSelectedItem());
        int jour = 1;
        DateFr dateFr = new DateFr(jour, mois, annee);
        String maDate = dateFr.toString();

        Bundle paquet = new Bundle();
        paquet.putString("dateRc", maDate);

        Intent intent = new Intent(this, ListeRvActivity.class);
        intent.putExtras(paquet);

        startActivity(intent);



        //testDonnee.setText("Année: " + this.spAnnee.getSelectedItem().toString() + " Mois: " + this.spMois.getSelectedItem().toString());

    }


    /*public void spMois(View vue){
        spMois.getSelectedItem();
    }*/
}
