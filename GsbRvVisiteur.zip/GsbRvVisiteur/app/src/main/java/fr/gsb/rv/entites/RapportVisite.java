package fr.gsb.rv.entites;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.Date;
import java.util.GregorianCalendar;

public class RapportVisite implements Parcelable{

    private String visiteur ;
    private int num;
    private String praticien;
    private String visMatricule ;
    private String nomVisiteur;
    private String prenomVisiteur;
    private String nomPraticien;
    private String prenomPraticien;
    private String bilan;
    private String vu = "non";
    private DateFr date;
    private String motif;
    private int coefficientDeConfiance;

    public RapportVisite(String visMatricule, String nomVisiteur, String prenomVisiteur, int num, String nomPraticien, String prenomPraticien, String bilan, String vu, DateFr date, String motif, int coefficientDeConfiance) {
        this.visMatricule = visMatricule;
        this.nomVisiteur = nomVisiteur;
        this.prenomVisiteur = prenomVisiteur;
        this.num = num;
        this.nomPraticien = nomPraticien;
        this.prenomPraticien = prenomPraticien;
        this.bilan = bilan;
        this.vu = vu;
        this.date = date;
        this.motif = motif;
        this.coefficientDeConfiance = coefficientDeConfiance;
    }

    public RapportVisite(String visiteur, int num, String praticien, String bilan, String vu, DateFr date, String motif, int coefficientDeConfiance) {
        this.visiteur = visiteur;
        this.num = num;
        this.praticien = praticien;
        this.bilan = bilan;
        this.vu = vu;
        this.date = date;
        this.motif = motif;
        this.coefficientDeConfiance = coefficientDeConfiance;
    }



/*
    public RapportVisite(String visiteur, int num, String praticien, String bilan, String dateString, String motif, int coefficientDeConfiance) {
        this.visiteur = visiteur;
        this.num = num;
        this.praticien = praticien;
        this.bilan = bilan;
        this.dateString = dateString;
        this.motif = motif;
        this.coefficientDeConfiance = coefficientDeConfiance;
    }

    public RapportVisite(String visiteur, String praticien, String bilan, DateFr date, String motif, int coefficientDeConfiance) {
        this.visiteur = visiteur;
        this.praticien = praticien;
        this.bilan = bilan;
        this.date = date;
        this.motif = motif;
        this.coefficientDeConfiance = coefficientDeConfiance;
    }

    public RapportVisite(String visiteur, int num, String praticien, String bilan, String vu, DateFr date, String motif, int coefficientDeConfiance) {
        this.visiteur = visiteur;
        this.num = num;
        this.praticien = praticien;
        this.bilan = bilan;
        this.vu = vu;
        this.date = date;
        this.motif = motif;
        this.coefficientDeConfiance = coefficientDeConfiance;
    }
    */

    public String getVisMatricule() {
        return visMatricule;
    }

    public void setVisMatricule(String visMatricule) {
        this.visMatricule = visMatricule;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags){

        dest.writeString(this.visMatricule);
        dest.writeString(this.nomVisiteur);
        dest.writeString(this.prenomVisiteur);
        dest.writeInt(this.num);
        dest.writeString(this.nomPraticien);
        dest.writeString(this.prenomPraticien);
        dest.writeString(this.bilan);
        dest.writeString(this.vu);
        dest.writeString(this.date.toString());
        dest.writeString(this.motif);
        dest.writeInt(this.coefficientDeConfiance);

    }

    public String getNomVisiteur() {
        return nomVisiteur;
    }

    public void setNomVisiteur(String nomVisiteur) {
        this.nomVisiteur = nomVisiteur;
    }

    public String getPrenomVisiteur() {
        return prenomVisiteur;
    }

    public void setPrenomVisiteur(String prenomVisiteur) {
        this.prenomVisiteur = prenomVisiteur;
    }

    public String getNomPraticien() {
        return nomPraticien;
    }

    public void setNomPraticien(String nomPraticien) {
        this.nomPraticien = nomPraticien;
    }

    public String getPrenomPraticien() {
        return prenomPraticien;
    }

    public void setPrenomPraticien(String prenomPraticien) {
        this.prenomPraticien = prenomPraticien;
    }

    public RapportVisite (Parcel in){

        this.visMatricule=in.readString();
        this.nomVisiteur=in.readString();
        this.prenomVisiteur=in.readString();
        this.num=in.readInt();
        this.prenomPraticien=in.readString();
        this.nomPraticien=in.readString();
        this.bilan=in.readString();
        this.vu=in.readString();
        this.date=new DateFr(in.readString());
        this.motif=in.readString();
        this.coefficientDeConfiance=in.readInt();

    }


    public static final Creator<RapportVisite> CREATOR= new Creator<RapportVisite>(){

        public RapportVisite createFromParcel (Parcel source){

            return new RapportVisite(source);

        }

        public RapportVisite[] newArray (int size){
            return new RapportVisite[size];
        }

    };

    public void setVisiteurMatricule(String visMatricule) {
        this.visMatricule= visMatricule;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public String getBilan() {
        return bilan;
    }

    public void setBilan(String bilan) {
        this.bilan = bilan;
    }

    public String getVu() {
        return vu;
    }

    public void setVu(String vu) {
        this.vu = vu;
    }

    public DateFr getDate() {
        return date;
    }

    public void setDate(DateFr date) {
        this.date = date;
    }

    public String getMotif() {
        return motif;
    }

    public void setMotif(String motif) {
        this.motif = motif;
    }

    public int getCoefficientDeConfiance() {
        return coefficientDeConfiance;
    }

    public void setCoefficientDeConfiance(int coefficientDeConfiance) {
        this.coefficientDeConfiance = coefficientDeConfiance;
    }

    @Override
    public String toString() {
        return "RapportVisite{" +
                "nomVisiteur='" + nomVisiteur + '\'' +
                ", prenomVisiteur='" + prenomVisiteur + '\'' +
                ", num=" + num +
                ", nomPraticien='" + nomPraticien + '\'' +
                ", prenomPraticien='" + prenomPraticien + '\'' +
                ", bilan='" + bilan + '\'' +
                ", vu='" + vu + '\'' +
                ", date=" + date +
                ", motif='" + motif + '\'' +
                ", coefficientDeConfiance=" + coefficientDeConfiance +
                '}';
    }
}
