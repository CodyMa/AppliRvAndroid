package fr.gsb.rv.gsb_rv_visiteur;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;

import java.lang.reflect.Array;
import java.time.Year;
import java.util.ArrayList;

import fr.gsb.rv.entites.DateFr;
import fr.gsb.rv.entites.RapportVisite;
import fr.gsb.rv.technique.Url;

public class ListeRvActivity extends AppCompatActivity {

    TextView tvMois;
    TextView tvAnnee;

    private String mois;
    private String annee;
    ListView lvRapportsVisite;
    private ArrayList<RapportVisite> lesRvSelectionnes = new ArrayList<RapportVisite>();
    private ArrayList<String> lesRv = new ArrayList<String>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_liste_rv);


        //paquet de l'activité RechercherRvAtivity
        Bundle paquet = this.getIntent().getExtras();
        DateFr date = new DateFr(paquet.getString("dateRc"));

        // mois et annéé récupérer, choisis par l'utilisateur
        mois = ""+date.getMois();
        //System.out.println(mois);
        annee = ""+date.getAnnee();
        //System.out.println(annee);

        tvMois = (TextView) findViewById(R.id.tvMois);
        tvAnnee = (TextView) findViewById(R.id.tvAnnee);

        // mois et annee dans le textView
        tvMois.setText(mois);
        tvAnnee.setText(annee);
        //
        lvRapportsVisite = (ListView) findViewById(R.id.lvRapportsVisite);

        // route
        String url = "http://"+ Url.getUrl().getLUrl()+":5000/listeRv/" + mois + "/" + annee;

        // Création de l'écouteur
        Response.Listener<JSONArray> ecouteurReponse = new Response.Listener<JSONArray>()   {
            @Override
            public void onResponse(JSONArray response) {

                try{
                    for(int i = 0; i < response.length(); i++){

                        Log.i("App-Gsb", response.getJSONObject(i).getString("numRv"));
                        //on recupère la date
                        //String dateRest = response.getJSONObject(i).getString("date");

                        //on récupère la date et on splite de la date dans un tableau
                        String[] dateSpliteRest = response.getJSONObject(i).getString("dateRv").split("-");
                        // on récupère chaque ligne dans une variable qu'on parse en integer
                        int year = Integer.parseInt(dateSpliteRest[0]);
                        int mounth = Integer.parseInt(dateSpliteRest[1]);
                        int day = Integer.parseInt(dateSpliteRest[2]);
                        // on instancie en DateFr
                        DateFr maDate = new DateFr(day, mounth,year);
                        System.out.println(day + mounth + year );
                        //Instance du rapport
                        RapportVisite leRapport = new RapportVisite(
                                response.getJSONObject(i).getString("matricule"),
                                response.getJSONObject(i).getString("visNom"),
                                response.getJSONObject(i).getString("visPrenom"),
                                response.getJSONObject(i).getInt("numRv"),
                                response.getJSONObject(i).getString("praNom"),
                                response.getJSONObject(i).getString("praPrenom"),
                                response.getJSONObject(i).getString("bilanRv"),
                                response.getJSONObject(i).getString("vuRv"),
                                maDate,
                                response.getJSONObject(i).getString("libelleMotif"),
                                response.getJSONObject(i).getInt("coefConfRv")
                        );

                        System.out.println("Mon rapport:" + leRapport);

                        //Ajout du rapport à la liste de rapports
                        if(leRapport != null){
                            lesRvSelectionnes.add(leRapport);
                        }
                    }

                    for (RapportVisite unRv : lesRvSelectionnes) {
                        lesRv.add("Rapport n° : " + unRv.getNum()
                                + " du " + unRv.getDate()
                                + "\nVisiteur : " + unRv.getNomVisiteur() + " " +unRv.getPrenomVisiteur()
                                + "\nMotif : " + unRv.getMotif()
                                + "\n");
                    }

                    //Création de l'adapteur
                    ArrayAdapter<String> adaptateur = new ArrayAdapter<String>(
                            ListeRvActivity.this,
                            android.R.layout.simple_list_item_1,
                            lesRv
                    ) ;

                    //liaison de l'adapteur au composant ListView
                    lvRapportsVisite.setAdapter(adaptateur);


                    lvRapportsVisite.setOnItemClickListener(
                            new AdapterView.OnItemClickListener() {
                                @Override
                                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                    String rvSelecionneString = lesRv.get(position);

                                    RapportVisite rvSelecionne = lesRvSelectionnes.get(position);

                                    Bundle paquet = new Bundle();
                                    paquet.putParcelable("rvSelectionne", rvSelecionne );


                                    //Intentention envoyé à la prochaine activité avec le paquet
                                    Intent intentRv = new Intent(ListeRvActivity.this, VisuRvActivity.class);
                                    intentRv.putExtras(paquet);

                                    startActivity(intentRv);
                                }
                            }
                    );


                }catch (Exception e){
                    Log.e("App-Gsb", "Erreur JSON: " + e.getMessage());
                }


            }
        };


        Response.ErrorListener ecouteurErreur = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("App-Gsb", "Erreur HTTP: " + error.getMessage());
            }
        };

        JsonArrayRequest requete = new JsonArrayRequest(Request.Method.GET , url , null, ecouteurReponse, ecouteurErreur);
        RequestQueue fileReq = Volley.newRequestQueue(ListeRvActivity.this);
        fileReq.add(requete);

    }

}
