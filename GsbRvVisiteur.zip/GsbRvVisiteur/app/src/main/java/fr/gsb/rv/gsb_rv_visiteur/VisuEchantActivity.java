package fr.gsb.rv.gsb_rv_visiteur;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

import fr.gsb.rv.entites.DateFr;
import fr.gsb.rv.entites.Echantillons;
import fr.gsb.rv.entites.RapportVisite;

public class VisuEchantActivity extends AppCompatActivity {

    ArrayList<Echantillons> lesEchantsSelectionne ;

    TextView tvEchantAffiche;
    ListView lvEchantillons;

    private ArrayList<String> lesEchants = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visu_echant);

        lvEchantillons = (ListView) findViewById(R.id.lvEchantillons);
        tvEchantAffiche = (TextView) findViewById(R.id.tvEchantAffiche);


        //paquet de l'activité VisuRvActivity
        Bundle paquet = this.getIntent().getExtras();

        System.out.println(paquet);

        lesEchantsSelectionne = paquet.getParcelableArrayList("lesEchantsSelectionne");

        System.out.println("lesEchantsSelection : " + lesEchantsSelectionne);
        //System.out.println("lesEchantsSelection : " + paquet.getParcelableArrayList("LesEchantsSelectionne"))
        if( paquet != null ){

            System.out.println("lesEchantsSelection : " + paquet.getParcelableArrayList("LesEchantsSelectionne"));

            lesEchantsSelectionne = paquet.getParcelableArrayList("lesEchantsSelectionne");

            for (Echantillons unEchant : lesEchantsSelectionne) {
                lesEchants.add( "Nom Commercial : " + unEchant.getNomCommercial() + " # " +
                                "Quantite : " + unEchant.getQuantite() ) ;
            }

            //Création de l'adapteur
            ArrayAdapter<String> adaptateur = new ArrayAdapter<String>(
                    VisuEchantActivity.this,
                    android.R.layout.simple_list_item_1,
                    lesEchants
            ) ;

            //liaison de l'adapteur au composant ListView
            lvEchantillons.setAdapter(adaptateur);

            lvEchantillons.setOnItemClickListener(
                    new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                            Echantillons EchantSelectionne = lesEchantsSelectionne.get(position);

                            System.out.println("Echant Selectionné : " + EchantSelectionne);


                            String TexteEchantAffiche = "Effets : " + EchantSelectionne.getMedEffets() + "\n"
                                    + "Contre indication :" + EchantSelectionne.getMedContreIndic() + "\n"
                                    + "Dépot Légal :" + EchantSelectionne.getDepotLegalMedoc() + "\n"
                                    + "Famille : " + EchantSelectionne.getFamLibelle() + "\n"
                                    + "Composition : " + EchantSelectionne.getMedComposition() + "\n"
                                    + "Prix : " + EchantSelectionne.getMedPrixEchant() + "\n" ;

                            System.out.println("Texte echantillon : " + TexteEchantAffiche);

                            if(tvEchantAffiche.getText().equals(TexteEchantAffiche)){
                                tvEchantAffiche.setText("");
                            }
                            else{
                                tvEchantAffiche.setText( TexteEchantAffiche );
                            }

                            /*public class FireMissilesDialogFragment extends DialogFragment {
                                @Override
                                public Dialog onCreateDialog(Bundle savedInstanceState) {
                                    // Use the Builder class for convenient dialog construction
                                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                                    builder.setMessage(
                                            "Test"
                                    )
                                            .setNegativeButton(R.string.ok, new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int id) {
                                                    // FIRE ZE MISSILES!
                                                }
                                            });
                                    // Create the AlertDialog object and return it
                                    return builder.create();
                                }
                            }*/

                        }
                    }
            );
        }else{


            lesEchants.add( "Aucun échantillon pour ce rapport" ) ;


            //Création de l'adapteur
            ArrayAdapter<String> adaptateur = new ArrayAdapter<String>(
                    VisuEchantActivity.this,
                    android.R.layout.simple_list_item_1,
                    lesEchants
            ) ;

            //liaison de l'adapteur au composant ListView
            lvEchantillons.setAdapter(adaptateur);


        }






    }

}
