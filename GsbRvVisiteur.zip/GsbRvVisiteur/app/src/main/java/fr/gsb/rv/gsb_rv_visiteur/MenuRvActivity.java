package fr.gsb.rv.gsb_rv_visiteur;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import org.w3c.dom.Text;

import fr.gsb.rv.technique.Session;

public class MenuRvActivity extends AppCompatActivity {

    TextView idCo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_rv);

        //idCo.setText("Vous êtes connecté, " + Session.getSession().getLeVisiteur().getNom() + " " + Session.getSession().getLeVisiteur().getPrenom() );
        //récupère le paquet reçu par l'activité précedénte via l'intention
        Bundle paquet = this.getIntent().getExtras();
        //Récupère le message du paquet messageAccueil avec le quel on lui a afffecté la variable text
        String messageAccueil = paquet.getString("messageAccueil");


        //récupère l'id du textView
        idCo = findViewById(R.id.idCo);
        //
        idCo.setText(messageAccueil + "\n");

    }


    public void SelectRv(View vue){

        Intent intent = new Intent(this, RechercherRvActivity.class);
        startActivity(intent);
    }

    public void SaisirRv(View vue){

        Intent intent = new Intent(this, SaisirRvActivity.class);
        startActivity(intent);
    }
}
