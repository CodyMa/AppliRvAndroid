package fr.gsb.rv.technique;

import fr.gsb.rv.entites.Visiteur;
import fr.gsb.rv.modeles.ModeleGsb;

public class Url {

	private static Url url = null ;
	private String LUrl ;

	private Url(String LUrl){
		super() ;
		this.LUrl = LUrl ;
	}
	
	public static void ouvrir(String LUrl){
			Url.url = new Url( LUrl ) ;
	}
	
	public static Url getUrl(){
		return Url.url ;
	}
	
	public static void fermer(){
		Url.url = null ;
	}
	
	public String getLUrl(){
		return this.LUrl ;
	}
}
