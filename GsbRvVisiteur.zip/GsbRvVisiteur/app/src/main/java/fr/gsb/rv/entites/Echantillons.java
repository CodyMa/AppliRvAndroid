package fr.gsb.rv.entites;

import android.os.Parcel;
import android.os.Parcelable;

public class Echantillons implements Parcelable {

	private String depotLegalMedoc;
	private String nomCommercial;
	private String famLibelle;
	private String medComposition;
	private String medEffets;
	private String medContreIndic;
	private String medPrixEchant;
	private String visMatricule;
	private int numRapport;
	private int quantite;

    public Echantillons(String depotLegalMedoc, String nomCommercial, String famLibelle, String medComposition, String medEffets, String medContreIndic, String medPrixEchant) {
        this.depotLegalMedoc = depotLegalMedoc;
        this.nomCommercial = nomCommercial;
        this.famLibelle = famLibelle;
        this.medComposition = medComposition;
        this.medEffets = medEffets;
        this.medContreIndic = medContreIndic;
        this.medPrixEchant = medPrixEchant;
    }

    public Echantillons(String depotLegalMedoc, String nomCommercial, String famLibelle, String medComposition, String medEffets, String medContreIndic, String medPrixEchant, int quantite) {
        this.depotLegalMedoc = depotLegalMedoc;
        this.nomCommercial = nomCommercial;
        this.famLibelle = famLibelle;
        this.medComposition = medComposition;
        this.medEffets = medEffets;
        this.medContreIndic = medContreIndic;
        this.medPrixEchant = medPrixEchant;
        this.quantite = quantite;
    }

    public Echantillons(String depotLegalMedoc, String nomCommercial, String famLibelle, String medComposition, String medEffets, String medContreIndic, String medPrixEchant, int numRapport, int quantite) {
        this.depotLegalMedoc = depotLegalMedoc;
        this.nomCommercial = nomCommercial;
        this.famLibelle = famLibelle;
        this.medComposition = medComposition;
        this.medEffets = medEffets;
        this.medContreIndic = medContreIndic;
        this.medPrixEchant = medPrixEchant;
        this.numRapport = numRapport;
        this.quantite = quantite;
    }


    protected Echantillons(Parcel in) {
        depotLegalMedoc = in.readString();
        nomCommercial = in.readString();
        famLibelle = in.readString();
        medComposition = in.readString();
        medEffets = in.readString();
        medContreIndic = in.readString();
        medPrixEchant = in.readString();
        visMatricule = in.readString();
        quantite = in.readInt();
    }

    public static final Creator<Echantillons> CREATOR = new Creator<Echantillons>() {
        @Override
        public Echantillons createFromParcel(Parcel in) {
            return new Echantillons(in);
        }

        @Override
        public Echantillons[] newArray(int size) {
            return new Echantillons[size];
        }
    };

    public String getDepotLegalMedoc() {
		return depotLegalMedoc;
	}

	public void setDepotLegalMedoc(String depotLegalMedoc) {
		this.depotLegalMedoc = depotLegalMedoc;
	}

	public String getVisMatricule() {
		return visMatricule;
	}

	public void setVisMatricule(String visMatricule) {
		this.visMatricule = visMatricule;
	}

	public int getNumRapport() {
		return numRapport;
	}

	public void setNumRapport(int numRapport) {
		this.numRapport = numRapport;
	}

	public int getQuantite() {
		return quantite;
	}

	public void setQuantite(int quantite) {
		this.quantite = quantite;
	}

    public String getNomCommercial() {
        return nomCommercial;
    }

    public void setNomCommercial(String nomCommercial) {
        this.nomCommercial = nomCommercial;
    }

    public String getFamLibelle() {
        return famLibelle;
    }

    public void setFamLibelle(String famLibelle) {
        this.famLibelle = famLibelle;
    }

    public String getMedComposition() {
        return medComposition;
    }

    public void setMedComposition(String medComposition) {
        this.medComposition = medComposition;
    }

    public String getMedEffets() {
        return medEffets;
    }

    public void setMedEffets(String medEffets) {
        this.medEffets = medEffets;
    }

    public String getMedContreIndic() {
        return medContreIndic;
    }

    public void setMedContreIndic(String medContreIndic) {
        this.medContreIndic = medContreIndic;
    }

    public String getMedPrixEchant() {
        return medPrixEchant;
    }

    public void setMedPrixEchant(String medPrixEchant) {
        this.medPrixEchant = medPrixEchant;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(depotLegalMedoc);
        dest.writeString(nomCommercial);
        dest.writeString(famLibelle);
        dest.writeString(medComposition);
        dest.writeString(medEffets);
        dest.writeString(medContreIndic);
        dest.writeString(medPrixEchant);
        dest.writeString(visMatricule);
        dest.writeInt(quantite);
    }


    @Override
	public String toString() {
		return "Echantillons{" +
				"depotLegalMedoc='" + depotLegalMedoc + '\'' +
				", visMatricule='" + visMatricule + '\'' +
				", numRapport=" + numRapport +
				", quantite=" + quantite +
				'}';
	}


}
