package fr.gsb.rv.gsb_rv_visiteur;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;

import java.util.ArrayList;

import fr.gsb.rv.entites.DateFr;
import fr.gsb.rv.entites.Echantillons;
import fr.gsb.rv.entites.RapportVisite;
import fr.gsb.rv.technique.Url;

public class VisuRvActivity extends AppCompatActivity {

    TextView tvNumRv;
    TextView tvDateRv;
    TextView tvVisiteur;
    TextView tvPraticien;
    TextView tvBilanRv;
    TextView tvMotif;
    TextView tvCoeffConf;
    private String numRv;
    private String matricule;
    //ListView lvEchantillons;

    private ArrayList<Echantillons> lesEchantsSelectionne = new ArrayList<Echantillons>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visu_rv);

        //paquet de l'activité RechercherRvAtivity
        Bundle paquet = this.getIntent().getExtras();
        //DateFr date = new DateFr(paquet.getString("dateRc"));
        RapportVisite rvSelectionne = paquet.getParcelable("rvSelectionne");
        System.out.println("rvSelectionne : " + rvSelectionne);

        //numéro du rapport de visite
        numRv = "" + rvSelectionne.getNum();
        System.out.println("numRv: " + numRv);

        matricule = "" + rvSelectionne.getVisMatricule();
        //nom et prénom du visiteur qu'on concatène
        String nomVisiteur = rvSelectionne.getNomVisiteur();
        String prenomVisiteur = rvSelectionne.getPrenomVisiteur();
        String visiteur = nomVisiteur + " " + prenomVisiteur;

        //nom et prénom du praticien qu"on concatène
        String nomPra = rvSelectionne.getNomPraticien();
        String prePra = rvSelectionne.getPrenomPraticien();
        String praticien = nomPra + " " + prePra;

        //bilan du rapport de visite
        String bilanRv = rvSelectionne.getBilan();

        //motif du rapport de visite
        String motif = rvSelectionne.getMotif();

        // on récupère la date sous forme de dateFr
        DateFr date = rvSelectionne.getDate();

        //
        String coeffC = ""+rvSelectionne.getCoefficientDeConfiance();

        //TextView et on set le text avec le numRv qu'on récupère avec le paquet
        tvNumRv = (TextView) findViewById(R.id.tvNumRv);
        String tvNumRvText = tvNumRv.getText() + " " + numRv;
        System.out.println("tvNumRvText: " + tvNumRvText);
        tvNumRv.setText(tvNumRvText);

        tvDateRv = (TextView) findViewById(R.id.tvDateRv);
        tvDateRv.setText(date.toString());

        tvVisiteur = (TextView) findViewById(R.id.tvVisiteur);
        tvVisiteur.setText(visiteur);

        tvPraticien = (TextView)findViewById(R.id.tvPraticien);
        tvPraticien.setText(praticien);

        tvBilanRv = (TextView) findViewById(R.id.tvBilanRv);
        tvBilanRv.setText(bilanRv);

        tvMotif = (TextView) findViewById(R.id.tvMotif);
        tvMotif.setText(motif);

        tvCoeffConf = (TextView) findViewById(R.id.tvCoeffConf);
        tvCoeffConf.setText(coeffC);



    }

    public void ConsulterEchants(View vue){

        //route
        String url = "http://"+ Url.getUrl().getLUrl()+":5000/echantillons/" + numRv + "/" + matricule;

        // Création de l'écouteur
        Response.Listener<JSONArray> ecouteurReponse = new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {

                try{
                    //Vider la listeavant de la remplir
                    lesEchantsSelectionne.clear();

                    for(int i = 0; i < response.length(); i++){
                        Log.i("App-Gsb", response.getJSONObject(i).getString("depotLegal"));

                        Echantillons LEchant = new Echantillons(
                                response.getJSONObject(i).getString("depotLegal"),
                                response.getJSONObject(i).getString("nomCommercial"),
                                response.getJSONObject(i).getString("famLibelle"),
                                response.getJSONObject(i).getString("composition"),
                                response.getJSONObject(i).getString("effets"),
                                response.getJSONObject(i).getString("contreIndications"),
                                response.getJSONObject(i).getString("prixEchantillon"),
                                response.getJSONObject(i).getInt("quantite")
                                );

                        System.out.println("LEchant" + LEchant);
                        //Ajout de l'éhantillons à la liste d'échantillons
                        if(LEchant != null){
                            lesEchantsSelectionne.add(LEchant);
                        }
                    }


                    Bundle paquet = new Bundle();
                    //System.out.println("PAQUET AVANT: " + paquet);
                    //System.out.println(lesEchantsSelectionne);
                    paquet.clear();
                    //System.out.println("PAQUET APRES: " + paquet);
                    paquet.putParcelableArrayList("lesEchantsSelectionne", lesEchantsSelectionne);


                    Intent intent = new Intent(VisuRvActivity.this, VisuEchantActivity.class);
                    //intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    intent.putExtras(paquet);
                    startActivity(intent);


                }catch (Exception e){
                    Log.e("App-Gsb", "Erreur JSON: " + e.getMessage());
                    Intent intent = new Intent(VisuRvActivity.this, VisuEchantActivity.class);
                    startActivity(intent);
                }
            }
        };

        Response.ErrorListener ecouteurErreur = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("App-Gsb", "Erreur HTTP: " + error.getMessage());
            }
        };

        JsonArrayRequest requete = new JsonArrayRequest(Request.Method.GET , url , null, ecouteurReponse, ecouteurErreur);
        RequestQueue fileReq = Volley.newRequestQueue(VisuRvActivity.this);
        fileReq.add(requete);


    }

}
