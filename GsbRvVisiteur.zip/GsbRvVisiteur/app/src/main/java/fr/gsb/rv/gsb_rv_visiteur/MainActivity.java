package fr.gsb.rv.gsb_rv_visiteur;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.text.BreakIterator;

import fr.gsb.rv.entites.Visiteur;
import fr.gsb.rv.modeles.ModeleGsb;
import fr.gsb.rv.technique.Session;
import fr.gsb.rv.technique.Url;

public class MainActivity extends AppCompatActivity {

    //TextView errorMessage;
    EditText etMatricule;
    EditText etMdp;
    TextView infoMsg ;

    //private ModeleGsb modele ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        infoMsg = (TextView) findViewById(R.id.infoMsg);
        infoMsg.setText("");
        etMatricule = (EditText) findViewById(R.id.etMatricule);
        etMatricule.setText("");
        etMdp = (EditText) findViewById(R.id.etMdp);
        etMdp.setText("");
        Url.ouvrir("192.168.1.68");
        //Toast.makeText(this,"Test",Toast.LENGTH_LONG).show();
    }
    public void seConnecter (View vue){

        final String matricule = etMatricule.getText().toString();
        final String mdp = etMdp.getText().toString();

        System.out.println(matricule + " " + mdp);
        final Visiteur leVisiteur = new Visiteur();

        String url = "http://" + Url.getUrl().getLUrl() + ":5000/connexion/" + matricule + "/" + mdp;
        System.out.println(url);

        try {
            System.out.println("Test try");
            url = "http://" + Url.getUrl().getLUrl() + ":5000/connexion/" + matricule + "/" + mdp;
            Response.Listener<JSONObject> ecouteurReponse = new Response.Listener<JSONObject>() {

                @Override
                public void onResponse(JSONObject response) {
                    //System.out.println("Test onResponse");

                    try {
                        //System.out.println("onResponse Test après try");

                        leVisiteur.setMatricule(matricule);
                        leVisiteur.setMdp(mdp);
                        leVisiteur.setPrenom(response.getString("prenom"));
                        leVisiteur.setNom(response.getString("nom"));

                        Session.fermer();
                        Session.ouvrir( leVisiteur );
                        //Session session = Session.getSession();
                        //boolean session = Session.ouvrir(leVisiteur);


                        etMdp.setText("");
                        etMatricule.setText("");
                        //infoMsg.setText("Vous êtes connecté, " + Session.getSession().getLeVisiteur().getNom() + " " + Session.getSession().getLeVisiteur().getPrenom() );

                        Context context = getApplicationContext();
                        CharSequence text = "Bonjour " +  Session.getSession().getLeVisiteur().getNom() + " " + Session.getSession().getLeVisiteur().getPrenom() ;
                        int duration = Toast.LENGTH_LONG;

                        Bundle paquet = new Bundle();
                        paquet.putString("messageAccueil", (String) text);


                        Toast toast = Toast.makeText(context, text, duration);
                        toast.show();

                        Intent intent = new Intent(MainActivity.this, MenuRvActivity.class);
                        intent.putExtras(paquet);

                        startActivity(intent);


                    }catch (Exception e){
                        Log.e(
                                "App-Rv", "Erreur JSON" + e.getMessage()
                        );
                    }
                }
            };



            Response.ErrorListener ecouteurErreur= new Response.ErrorListener(){

                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e("App-Gsb", "Erreur HTTP : " + error.getMessage() + ".");

                    int httpStatusCode = 500;
                    if(error.networkResponse != null){
                        httpStatusCode = error.networkResponse.statusCode;
                    }


                    if(httpStatusCode==404){
                        //Traitement pour informer l'utilisateur qu'il a fait une erreur
                        //etMatricule.setText("");
                        etMdp.setText("");
                        //errorMessageText = "Votre login ou mdp est incorrect";
                        infoMsg.setText("Votre login ou mdp est incorrect\n");
                                //+ System.lineSeparator()+ System.lineSeparator()+ System.lineSeparator());

                        Context context = getApplicationContext();
                        CharSequence text = "Votre login ou mdp est incorrect";
                        int duration = Toast.LENGTH_LONG;

                        Toast toast = Toast.makeText(context, text, duration);
                        toast.show();
                    }
                    else if (matricule == "" || mdp == ""){
                        //Traitement pour informer l'utilisateur qu'il a fait une erreur
                        //errorMessageText = "Votre login ou mdp est incorrect";
                        infoMsg.setText("Votre login ou mdp n'est pas renseigné \n");
                                //+ System.lineSeparator()+ System.lineSeparator()+ System.lineSeparator());

                        Context context = getApplicationContext();
                        CharSequence text = "Votre login ou mdp n'est pas renseigné";
                        int duration = Toast.LENGTH_LONG;

                        Toast toast = Toast.makeText(context, text, duration);
                        toast.show();
                    }
                    else{
                        //Traitement pour informer l'utilisateur que le serveur est injoignable
                        //errorMessageText = "Votre login ou mdp est incorrect";
                        infoMsg.setText("Le serveur est injoignable \n");
                                //+ System.lineSeparator()+ System.lineSeparator()+ System.lineSeparator());

                        Context context = getApplicationContext();
                        CharSequence text = "Le serveur est injoignable";
                        int duration = Toast.LENGTH_LONG;

                        Toast toast = Toast.makeText(context, text, duration);
                        toast.show();
                    }
                }
            };


            JsonObjectRequest requete = new JsonObjectRequest
                    (Request.Method.GET, url , null, ecouteurReponse, ecouteurErreur);


            RequestQueue fileAttente = Volley.newRequestQueue( MainActivity.this ) ;
            fileAttente.add( requete );

        }catch (Exception e){
            System.out.println("erreur");
        }

    }
    public void annuler(View vue){

        etMdp.setText("");
        etMatricule.setText("");
        Context context = getApplicationContext();
        CharSequence text = "Vous avez annulé l'authentification";
        int duration = Toast.LENGTH_LONG;

        Toast toast = Toast.makeText(context, text, duration);
        toast.show();

    }

}
