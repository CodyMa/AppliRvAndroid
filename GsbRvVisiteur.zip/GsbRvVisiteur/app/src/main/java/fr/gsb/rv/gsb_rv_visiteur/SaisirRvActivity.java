package fr.gsb.rv.gsb_rv_visiteur;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.DatePicker;
import android.widget.TextView;

import java.util.GregorianCalendar;

import fr.gsb.rv.entites.DateFr;

public class SaisirRvActivity extends AppCompatActivity{

    //private Context mContext;
    //private Activity mActivity;



    TextView tvDateSelection;

    DatePickerDialog.OnDateSetListener ecouteurDate = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

            String dateSelection = String.format( "%02d/%02d/%04d" ,
                    dayOfMonth ,
                    monthOfYear + 1,
                    year
            );

            tvDateSelection.setText( dateSelection );

            DateFr laDateSelection = new DateFr(year, monthOfYear, dayOfMonth);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saisir_rv);

        // Get the application context
        //mContext = getApplicationContext();

        tvDateSelection = (TextView) findViewById(R.id.tvDateSelection);


    }

    public void selectionDate(View vue){

        DateFr dateJour = new DateFr(""+tvDateSelection.getText());

        int jour = dateJour.getJour();
        int mois = dateJour.getMois() - 1;
        int annee = dateJour.getAnnee();

        DatePickerDialog picker = new DatePickerDialog(this, ecouteurDate, annee, mois, jour);
        picker.show();

    }

}
