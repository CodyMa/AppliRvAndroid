package fr.gsb.rv.entites;

public class TypePraticien {
}
